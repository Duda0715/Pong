var nivelDificuldade = Number(window.prompt("Qual a o nível de dificuladade você gostaria de jogar? Resposta de 1 a 10")) //pedido para o jogador solicitar o nível de dificuldade ele quer.

//variaveis da tela
var largura = 600; //largura de 600 pixels.
var altura = 400; //altura de 400 pixels.
var corTabuleiro = "#40E0D0"; //cor do tabuleiro.

//variaveis de movimentação
var velocidadeX = nivelDificuldade; //velocidade da bolinha em x de acordo com o nível que o jogador solicitou.
var velocidadeY = nivelDificuldade; //velocidade da bolinha em y de acordo com o nível que o jogador solicitou.


//variaveis da bolinha
var xBolinha = 300; //posição da largura da bolinha.
var yBolinha = 200; //posição de altura da bolinha.
var dBolinha = 20; //diametro da bolinha.

//variaveis da raquete 1
var xRaquete1 = 20; //coordenada sobre largura da raquete
var yRaquete1 = 150; //coordenada sobre altura da raquete
var lRaquete1 = 10; //largura da raquete
var aRaquete1 = 100; //altura da raquete
var vRaquete1 = nivelDificuldade * 2; //velociade da raquete
var pontos1 = 0;

//variaveis da raquete 2
var xRaquete2 = 570; //coordenada sobre largura da raquete
var yRaquete2 = 150; //coordenada sobre altura da raquete
var lRaquete2 = 10; //largura da raquete
var aRaquete2 = 100; //altura da raquete
var vRaquete2 = nivelDificuldade * 2; //velociade da raquete
var pontos2 = 0;


//funções
function setup() {
  createCanvas(largura, altura); //quadrado de largura 600 pixels e altura 400 pixels.
}


function criarTabuleiro(corTabuleiro){
    background(corTabuleiro); //cor do quadrado é preto. Se for cor em hexadecimal temos que colocar dentro de aspas.
}


function criarBolinha(){
  circle(xBolinha, yBolinha, 20); //bolinha que seu centro fica na largura 300 pixels, altura 200 pixels, que no caso vai ficar no meio, pois é a metade da largura e altura total, e 20 é o tamanho da bolinha.
  fill(0, 0, 0);
}


function movimentarBolinha(){
   xBolinha = xBolinha+velocidadeX; //para a posição de largura da bolinha sempre aumentar 1 quando passar por esse comando em loop.
  yBolinha = yBolinha+velocidadeY; //para a posição de altura da bolinha sempre aumentar 1 quando passar por esse comando em loop.
}


function verificarColisaoParede(){
    if((xBolinha >= (600-(dBolinha/2))) || (xBolinha<(dBolinha/2))) {
    velocidadeX = -1 * velocidadeX
  }
    
    if((yBolinha >= (400-(dBolinha/2))) || (yBolinha<(dBolinha/2))) {
    velocidadeY = -1 * velocidadeY
      
  }
}


function criarRaquete1(xRaquete1, yRaquete1, lRaquete1, aRaquete1, corRaquete){
  rect(xRaquete1, yRaquete1, lRaquete1, aRaquete1);
}


function criarRaquete2(xRaquete2, yRaquete2, lRaquete2, aRaquete2, corRaquete){
rect(xRaquete2, yRaquete2, lRaquete2, aRaquete2);
}

function movimentarRaquete1(){
  if (keyIsDown(87)){ 
    if(yRaquete1 >= 0){
      yRaquete1 = yRaquete1 - vRaquete1; } 
  } 
  if (keyIsDown(83)){ 
    if (yRaquete1 <= (altura - aRaquete1)){
      yRaquete1 = yRaquete1 + vRaquete1; } 
  }
}

function movimentarRaquete2(){
  if (keyIsDown(UP_ARROW)){
    if(yRaquete2 >= 0){
      yRaquete2 = yRaquete2 - vRaquete2; } 
  } 
  if (keyIsDown(DOWN_ARROW)){ 
    if (yRaquete2 <= (altura - aRaquete2)){
      yRaquete2 = yRaquete2 + vRaquete2; } 
  }
}

 function verificarColisaoRaquete1(){ 
   if(xBolinha - (dBolinha/2) <= xRaquete1 + lRaquete1 && yBolinha - (dBolinha/2) <= yRaquete1 + aRaquete1 && yBolinha + (dBolinha/2) >= yRaquete1){
   velocidadeX = velocidadeX * -1 
   velocidadeY = velocidadeY * -1
     pontos2=pontos2+1
   }
     
 }
 

 function verificarColisaoRaquete2(){ 
   if (xBolinha + (dBolinha/2) >= xRaquete2 - lRaquete2 && yBolinha - (dBolinha/2) <= yRaquete2 + aRaquete2 && yBolinha + (dBolinha/2) >= yRaquete2){ 
     velocidadeX = velocidadeX * -1 
     velocidadeY = -1 * velocidadeY
   }
 }

function placar(){
textSize(22);
text("Player 1: "+ pontos1, (largura/2)-110, 22);
textSize(22);
text("Player 2: "+ pontos2, (largura/2)-110, 44);
fill(0, 102, 153)
  
}


function draw() { //função desenhar, é uma função de loop..
  criarTabuleiro(corTabuleiro);//chama a função criarTabuleiro.
  criarBolinha();//chama a função criarBolinha.
  movimentarBolinha();//chama a função movimentarBolinha.
  verificarColisaoParede(); //chama a função verificarColisao.
  criarRaquete1(xRaquete1, yRaquete1, lRaquete1, aRaquete1);
  criarRaquete2(xRaquete2, yRaquete2, lRaquete2, aRaquete2);
  movimentarRaquete1();
  movimentarRaquete2();
  verificarColisaoRaquete1();
  verificarColisaoRaquete2();
  placar();
  
}